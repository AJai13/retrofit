package up.retrofit

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import org.jsoup.Jsoup
import retrofit2.Call
import retrofit2.Retrofit
import retrofit2.converter.scalars.ScalarsConverterFactory
import up.retrofit.ui.theme.RetrofitTheme

val retrofit = Retrofit.Builder()
    .baseUrl("https://investidor10.com.br/")
    .addConverterFactory(ScalarsConverterFactory.create())
    .build()

val service = retrofit.create(Investidor10Service::class.java)

class MainActivity : ComponentActivity() {
    private val valorMercadoState = mutableStateOf<List<String>>(emptyList())
    private val dividendYieldState = mutableStateOf<List<String>>(emptyList())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            RetrofitTheme {
                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                ) { padding ->
                    Content(modifier = Modifier.padding(padding))
                }
            }
        }

        pegarValores()
    }

    private fun pegarValores() {
        val call = service.getPage("https://investidor10.com.br")
        call.enqueue(object : retrofit2.Callback<String> {
            override fun onResponse(call: Call<String>, response: retrofit2.Response<String>) {
                if (response.isSuccessful) {
                    val html = response.body()
                    val doc = Jsoup.parse(html)

                    val valorMercadoElements = doc.select("body > div.site > div.template-front-homepage-home-default > div > section:nth-child(3) > div:nth-child(1) > div.section-ranking--container > div > div:nth-child(1) > div > div:nth-child(3) > div > a")
                    val valorMercadoList = valorMercadoElements.map { it.text() }
                    valorMercadoState.value = valorMercadoList

                    val dividendYieldElements = doc.select("""
    body > div.site > div.template-front-homepage-home-default > div > section:nth-child(3) > div:nth-child(1) > div.section-ranking--container > div > div:nth-child(2) > div > div:nth-child(1) > div > a,
    body > div.site > div.template-front-homepage-home-default > div > section:nth-child(3) > div:nth-child(1) > div.section-ranking--container > div > div:nth-child(2) > div > div:nth-child(2) > div > a,
    body > div.site > div.template-front-homepage-home-default > div > section:nth-child(3) > div:nth-child(1) > div.section-ranking--container > div > div:nth-child(2) > div > div:nth-child(3) > div > a,
    body > div.site > div.template-front-homepage-home-default > div > section:nth-child(3) > div:nth-child(1) > div.section-ranking--container > div > div:nth-child(2) > div > div:nth-child(4) > div > a,
    body > div.site > div.template-front-homepage-home-default > div > section:nth-child(3) > div:nth-child(1) > div.section-ranking--container > div > div:nth-child(2) > div > div:nth-child(5) > div > a
""".trimIndent())
                    val dividendYieldList = dividendYieldElements.map { it.text() }
                    dividendYieldState.value = dividendYieldList

                } else {
                    println("Erro: ${response.errorBody()}")
                }
            }

            override fun onFailure(call: Call<String>, t: Throwable) {
                t.printStackTrace()
            }
        })
    }

    @Composable
    fun Content(modifier: Modifier = Modifier) {
        val valorMercado by valorMercadoState
        val dividendYield by dividendYieldState

        LazyColumn(modifier = modifier) {
            item {
                Text(text = "Maiores Valores de Mercado:")
            }
            items(valorMercado) { valor ->
                Text(text = valor)
            }
            item {
                Text(text = "")
                Text(text = "Maiores Dividend Yield:")
            }
            items(dividendYield) { dividend ->
                Text(text = dividend)
            }
        }
    }

    @Preview
    @Composable
    fun PreviewContent() {
        Content()
    }
}
